package VbroApplication;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Navigation;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class OneEndToEndOnVRBO {
	@Test
	public void demo() throws Throwable {

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disible-notifications");
		WebDriver driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		driver.get("https://www.vrbo.com/en-gb");
		WebElement destinationTextfield = driver.findElement(By.id("react-destination-typeahead"));
		destinationTextfield.sendKeys("BANGALORE");
		destinationTextfield.sendKeys(Keys.ENTER);
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,250);");
		Thread.sleep(2000);
		WebElement checkInDate = driver.findElement(By.xpath(
				"//div[@class='month multi simple']//tbody//td[@aria-label='14 April 2023']//div[@role='button']"));
		checkInDate.click();
		Thread.sleep(2000);
		WebElement checkOutDate = driver.findElement(By.xpath(
				"//div[@class='month multi simple']//tbody//td[@aria-label='30 April 2023']//div[@role='button']"));
		checkOutDate.click();
		Thread.sleep(2000);
		WebElement adultCountGuestDropdown = driver
				.findElement(By.xpath("//button[@type='button']//span[contains(.,'Increase Adults')]/.."));
		adultCountGuestDropdown.click();
		WebElement childCountGuestDropdown = driver
				.findElement(By.xpath("//button[@type='button']//span[contains(.,'Increase Children')]/.."));
		childCountGuestDropdown.click();
		WebElement ageDropDownInGuests = driver.findElement(By.id("age-select-0"));
		ageDropDownInGuests.click();
		Select selectTheAgeOfChild = new Select(ageDropDownInGuests);
		selectTheAgeOfChild.selectByValue("4");
		Thread.sleep(2000);
		WebElement applyButtonInGuestDropdown = driver.findElement(By.xpath("//span[text()='Apply']"));
		applyButtonInGuestDropdown.click();
		WebElement saveButtonDestinationSuggestionPage = driver
				.findElement(By.xpath("//div[@class='Hit__tripboardButton']"));
		saveButtonDestinationSuggestionPage.click();
		WebElement nameYourPlaceTextField = driver.findElement(By.id("createBoardNameInput-inline"));
		nameYourPlaceTextField.sendKeys("Honeymoon");
		WebElement saveButton2 = driver.findElement(By.xpath("//button[@class='btn btn-primary btn-sm']/.."));
		saveButton2.click();
		Thread.sleep(2000);
		WebElement tripBoards = driver.findElement(By.xpath("//div[@class='site-header-nav__scratchpad']"));
		tripBoards.click();
		driver.navigate().back();
		WebElement filterDropdown = driver.findElement(By.xpath("//div[@class='MoreFiltersModal']"));
		filterDropdown.click();
		WebElement houseCheckBox = driver
				.findElement(By.xpath("//div[@class='Modal__content']//span[text()='House']/.."));
		houseCheckBox.click();
		WebElement done = driver.findElement(By.xpath("//div[@class='Modal__footer']//button/.."));
		done.click();
		WebElement popular = driver.findElement(By.xpath(
				"//div[@class='Dropdown']//button[@class='btn btn-default FilterPill FilterPill--applied btn-xs']"));
		popular.click();
		WebElement priceDropdown = driver.findElement(By.xpath(
				"//div[@class='Dropdown']//button[@class='btn btn-default FilterPill btn-xs']//span[text()='Price']/../.."));
		priceDropdown.click();
		WebElement roomsAndSpaceDropdown = driver.findElement(By.xpath(
				"//div[@class='Dropdown']//button[@class='btn btn-default FilterPill btn-xs']//span[text()='Rooms and spaces']/../.."));
		roomsAndSpaceDropdown.click();
		WebElement sortdropdown = driver.findElement(By.xpath("//div[@class='SortDropDown']"));
		sortdropdown.click();
		WebElement recommended = driver.findElement(By.xpath("//li[@class='SortDropDownItem__selected']"));
		recommended.click();
		driver.navigate().refresh();

		Navigation navigate2 = driver.navigate();
		navigate2.to(
				"https://www.vrbo.com/en-gb/p4193548?adultsCount=1&arrival=2023-04-14&childrenCount=1&departure=2023-04-30&uni_id=4596650");
		Thread.sleep(3000);
		WebElement shareButton = driver
				.findElement(By.xpath("//button[@class='btn btn-default sharing-widget__button--expanded btn-xs']"));
		shareButton.click();
		WebElement aboutButton = driver.findElement(By.xpath("//li[@class='Navigation__li']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", aboutButton);
		WebElement facilitiesButton = driver.findElement(By.xpath("(//li[@class='Navigation__li'])[2]"));
		facilitiesButton.click();
		WebElement availabilityButton = driver.findElement(By.xpath("(//li[@class='Navigation__li'])[3]"));
		availabilityButton.click();
		WebElement hostButton = driver.findElement(By.xpath("(//li[@class='Navigation__li'])[4]"));
		hostButton.click();
		WebElement roomsAndBeds = driver.findElement(By.xpath("(//li[@class='Navigation__li'])[5]"));
		roomsAndBeds.click();
		WebElement reviewsButton = driver.findElement(By.xpath("(//li[@class='Navigation__li'])[6]"));
		reviewsButton.click();
		WebElement booknowbutton = driver.findElement(By.xpath("//div[@class='primary-cta']"));
		booknowbutton.click();
		Thread.sleep(2000);
		WebElement logoOfVrboAfterBooknow = driver
				.findElement(By.xpath("//a[@class='site-header-logo__link flex-item']"));
		logoOfVrboAfterBooknow.click();
		driver.manage().window().minimize();
		driver.quit();

	}
}
