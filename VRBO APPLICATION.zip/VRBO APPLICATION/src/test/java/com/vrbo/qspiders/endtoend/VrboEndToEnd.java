package com.vrbo.qspiders.endtoend;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import com.vrbo.qspiders.genericutility.BaseClass;
import com.vrbo.qspiders.pomrepository.VrboPropertiesPage;
import com.vrbo.qspiders.pomrepository.VrboRecommendedPropertyPage;
import com.vrbo.qspiders.pomrepository.VrbobookingPage;
import com.vrbo.qspiders.pomrepository.vrboHomePage;

public class VrboEndToEnd extends BaseClass {
	@Test
	public void BookOurDestination() throws FileNotFoundException, IOException {
		Actions actions = new Actions(driver);
		webdriverUtils.implicitWaitInSeconds(driver);
		vrboHomePage HomePage = new vrboHomePage(driver);
		VrboPropertiesPage PropertyPage = new VrboPropertiesPage(driver);
		VrboRecommendedPropertyPage RecommendedPropertyPage = new VrboRecommendedPropertyPage(driver);
		VrbobookingPage BookingPage = new VrbobookingPage(driver);
		HomePage.getDestinationTextfield().sendKeys(fileUtils.readData("destination"));
		HomePage.getDestinationTextfield().sendKeys(Keys.ENTER);
		HomePage.getCheckInDate().click();
		HomePage.getCheckOutDate().click();
		HomePage.getAdultCountGuestDropdown().click();
		HomePage.getChildCountGuestDropdown().click();
		HomePage.getAgeDropDownInGuests().sendKeys(fileUtils.readData("AgeOfChild"));
		actions.scrollByAmount(0, 200).pause(3000).perform();
		HomePage.getApplyButtonInGuestDropdown().click();
		PropertyPage.getSaveButtonDestinationSuggestionPage().click();
		PropertyPage.getNameSavePlaceTextField().sendKeys(fileUtils.readData("SavePlace"));
		PropertyPage.getSaveButton2().click();
		PropertyPage.getTripBoards().click();
		driver.navigate().back();
		PropertyPage.getFilterDropdown().click();
		PropertyPage.getHouseCheckBox().click();
		PropertyPage.getFilterpopupPageDoneButton().click();
		PropertyPage.getPopularPopup().click();
		PropertyPage.getPriceDropdown().click();
		PropertyPage.getRoomsAndSpaceDropdown().click();
		PropertyPage.getSortdropdown().click();
		PropertyPage.getRecommended().click();
		driver.navigate().to(fileUtils.readData("url2"));
		RecommendedPropertyPage.getShareButton().click();
		actions.scrollByAmount(0, 400).perform();
		RecommendedPropertyPage.getAboutButtonNavigationLink().click();
		RecommendedPropertyPage.getFacilitiesNavigationLink().click();
		RecommendedPropertyPage.getAvailabilityNavigationLink().click();
		RecommendedPropertyPage.getHostNavigationLink().click();
		RecommendedPropertyPage.getRoomsAndBedsNavigationLink().click();
		RecommendedPropertyPage.getReviewsNavigationLink().click();
		RecommendedPropertyPage.getLocationNavigationLink().click();
		RecommendedPropertyPage.getPoliciesNavigationLink().click();
		RecommendedPropertyPage.getBookNowButton().click();
		BookingPage.getLogoOfVrboAfterBookingPage().click();

	}
}
