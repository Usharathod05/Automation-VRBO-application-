package com.vrbo.qspiders.pomrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class vrboHomePage {
	WebDriver driver;

	public vrboHomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "react-destination-typeahead")
	private WebElement destinationTextfield;
	@FindBy(xpath = "//div[@class='month multi simple']//tbody//td[@aria-label='28 May 2023']//div[@role='button']")
	private WebElement checkInDate;
	@FindBy(xpath = "//div[@class='month multi simple']//tbody//td[@aria-label='30 May 2023']//div[@role='button']")
	private WebElement checkOutDate;
	@FindBy(xpath = "//button[@type='button']//span[contains(.,'Increase Adults')]/..")
	private WebElement adultCountGuestDropdown;
	@FindBy(xpath = "//button[@type='button']//span[contains(.,'Increase Children')]/..")
	private WebElement childCountGuestDropdown;
	@FindBy(id = "age-select-0")
	private WebElement ageDropDownInGuests;
	//private Select selectTheAgeOfChild = new Select(adultCountGuestDropdown);
	@FindBy(xpath  = "//span[text()='Apply']/parent::button")
	private WebElement applyButtonInGuestDropdown;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getDestinationTextfield() {
		return destinationTextfield;
	}

	public void setDestinationTextfield(WebElement destinationTextfield) {
		this.destinationTextfield = destinationTextfield;
	}

	public WebElement getCheckInDate() {
		return checkInDate;
	}

	public void setCheckInDate(WebElement checkInDate) {
		this.checkInDate = checkInDate;
	}

	public WebElement getCheckOutDate() {
		return checkOutDate;
	}

	public void setCheckOutDate(WebElement checkOutDate) {
		this.checkOutDate = checkOutDate;
	}

	public WebElement getAdultCountGuestDropdown() {
		return adultCountGuestDropdown;
	}

	public void setAdultCountGuestDropdown(WebElement adultCountGuestDropdown) {
		this.adultCountGuestDropdown = adultCountGuestDropdown;
	}

	public WebElement getChildCountGuestDropdown() {
		return childCountGuestDropdown;
	}

	public void setChildCountGuestDropdown(WebElement childCountGuestDropdown) {
		this.childCountGuestDropdown = childCountGuestDropdown;
	}

	public WebElement getAgeDropDownInGuests() {
		return ageDropDownInGuests;
	}

	public void setAgeDropDownInGuests(WebElement ageDropDownInGuests) {
		this.ageDropDownInGuests = ageDropDownInGuests;
	}

//	public Select getSelectTheAgeOfChild() {
//		return selectTheAgeOfChild;
//	}
//
//	public void setSelectTheAgeOfChild(Select selectTheAgeOfChild) {
//		this.selectTheAgeOfChild = selectTheAgeOfChild;
//	}

	public WebElement getApplyButtonInGuestDropdown() {
		return applyButtonInGuestDropdown;
	}

	public void setApplyButtonInGuestDropdown(WebElement applyButtonInGuestDropdown) {
		this.applyButtonInGuestDropdown = applyButtonInGuestDropdown;
	}
}
