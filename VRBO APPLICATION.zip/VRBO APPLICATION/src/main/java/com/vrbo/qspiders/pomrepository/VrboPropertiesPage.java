package com.vrbo.qspiders.pomrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class VrboPropertiesPage {
	WebDriver driver;

	public VrboPropertiesPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@class='Hit__tripboardButton']")
	private WebElement saveButtonDestinationSuggestionPage;
	@FindBy(id = "createBoardNameInput-inline")
	private WebElement nameSavePlaceTextField;
	@FindBy(xpath = "//button[@class='btn btn-primary btn-sm']/..")
	private WebElement saveButton2;
	@FindBy(xpath = "//div[@class='site-header-nav__scratchpad']")
	private WebElement tripBoards;
	@FindBy(xpath = "//div[@class='MoreFiltersModal']")
	private WebElement filterDropdown;
	@FindBy(xpath = "//div[@class='Modal__content']//span[text()='House']/..")
	private WebElement houseCheckBox;
	@FindBy(xpath = "//div[@class='Modal__footer']//button/..")
	private WebElement FilterpopupPageDoneButton;
	@FindBy(xpath = "//div[@class='Dropdown']//button[@class='btn btn-default FilterPill FilterPill--applied btn-xs']")
	private WebElement PopularPopup;
	@FindBy(xpath = "//div[@class='Dropdown']//button[@class='btn btn-default FilterPill btn-xs']//span[text()='Price']/../..")
	private WebElement priceDropdown;
	@FindBy(xpath = "//div[@class='Dropdown']//button[@class='btn btn-default FilterPill btn-xs']//span[text()='Rooms and spaces']/../..")
	private WebElement roomsAndSpaceDropdown;
	@FindBy(xpath = "//div[@class='SortDropDown']")
	private WebElement sortdropdown;
	@FindBy(xpath = "//li[@class='SortDropDownItem__selected']")
	private WebElement recommended;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getSaveButtonDestinationSuggestionPage() {
		return saveButtonDestinationSuggestionPage;
	}

	public void setSaveButtonDestinationSuggestionPage(WebElement saveButtonDestinationSuggestionPage) {
		this.saveButtonDestinationSuggestionPage = saveButtonDestinationSuggestionPage;
	}

	public WebElement getNameSavePlaceTextField() {
		return nameSavePlaceTextField;
	}

	public void setNameSavePlaceTextField(WebElement nameSavePlaceTextField) {
		this.nameSavePlaceTextField = nameSavePlaceTextField;
	}

	public WebElement getSaveButton2() {
		return saveButton2;
	}

	public void setSaveButton2(WebElement saveButton2) {
		this.saveButton2 = saveButton2;
	}

	public WebElement getTripBoards() {
		return tripBoards;
	}

	public void setTripBoards(WebElement tripBoards) {
		this.tripBoards = tripBoards;
	}

	public WebElement getFilterDropdown() {
		return filterDropdown;
	}

	public void setFilterDropdown(WebElement filterDropdown) {
		this.filterDropdown = filterDropdown;
	}

	public WebElement getHouseCheckBox() {
		return houseCheckBox;
	}

	public void setHouseCheckBox(WebElement houseCheckBox) {
		this.houseCheckBox = houseCheckBox;
	}

	public WebElement getFilterpopupPageDoneButton() {
		return FilterpopupPageDoneButton;
	}

	public void setFilterpopupPageDoneButton(WebElement filterpopupPageDoneButton) {
		FilterpopupPageDoneButton = filterpopupPageDoneButton;
	}

	public WebElement getPopularPopup() {
		return PopularPopup;
	}

	public void setPopularPopup(WebElement popularPopup) {
		PopularPopup = popularPopup;
	}

	public WebElement getPriceDropdown() {
		return priceDropdown;
	}

	public void setPriceDropdown(WebElement priceDropdown) {
		this.priceDropdown = priceDropdown;
	}

	public WebElement getRoomsAndSpaceDropdown() {
		return roomsAndSpaceDropdown;
	}

	public void setRoomsAndSpaceDropdown(WebElement roomsAndSpaceDropdown) {
		this.roomsAndSpaceDropdown = roomsAndSpaceDropdown;
	}

	public WebElement getSortdropdown() {
		return sortdropdown;
	}

	public void setSortdropdown(WebElement sortdropdown) {
		this.sortdropdown = sortdropdown;
	}

	public WebElement getRecommended() {
		return recommended;
	}

	public void setRecommended(WebElement recommended) {
		this.recommended = recommended;
	}

}
