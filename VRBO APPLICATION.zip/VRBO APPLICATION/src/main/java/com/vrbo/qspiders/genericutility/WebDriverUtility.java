package com.vrbo.qspiders.genericutility;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebDriverUtility {

	public void implicitWaitInSeconds(WebDriver driver) {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	}

	public void implicitWaitInMillis(WebDriver driver) {
		driver.manage().timeouts().implicitlyWait(Duration.ofMillis(5000));
	}

	public boolean verifyCompleteTitle(WebDriver driver, String expectedTitle) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		boolean validation = wait.until(ExpectedConditions.titleIs(expectedTitle));
		return validation;
	}

	public boolean verifyCompleteUrl(WebDriver driver, String expectedUrl) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		boolean validation = wait.until(ExpectedConditions.urlToBe(expectedUrl));
		return validation;
	}

	public WebDriver controlTransferToWindow(WebDriver driver, String windowId) {
		WebDriver upadateDriver = driver.switchTo().window(windowId);
		return upadateDriver;

	}

	public WebElement elementToBeClickable(WebDriver driver, WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		WebElement ele = wait.until(ExpectedConditions.elementToBeClickable(element));
		return ele;

	}

	public boolean partialTitle(WebDriver driver, String partialTitle) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		Boolean validation = wait.until(ExpectedConditions.titleIs(partialTitle));
		return validation;

	}

}
