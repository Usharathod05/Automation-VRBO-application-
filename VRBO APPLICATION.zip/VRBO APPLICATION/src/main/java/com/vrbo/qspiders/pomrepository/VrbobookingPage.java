package com.vrbo.qspiders.pomrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class VrbobookingPage {
	WebDriver driver;

	public VrbobookingPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[@class='site-header-logo__link flex-item']")
	private WebElement logoOfVrboAfterBookingPage;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getLogoOfVrboAfterBookingPage() {
		return logoOfVrboAfterBookingPage;
	}

	public void setLogoOfVrboAfterBookingPage(WebElement logoOfVrboAfterBookingPage) {
		this.logoOfVrboAfterBookingPage = logoOfVrboAfterBookingPage;
	}
	

}
