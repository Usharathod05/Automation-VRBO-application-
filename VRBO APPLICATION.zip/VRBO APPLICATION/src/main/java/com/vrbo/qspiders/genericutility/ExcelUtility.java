package com.vrbo.qspiders.genericutility;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ExcelUtility {
	public String readStringData(String sheetName, int rowindex, int cellindex)
			throws EncryptedDocumentException, IOException {
		FileInputStream fls = new FileInputStream("./src/test/resourcesexcelsampledata.xlxs");
		Workbook workbook = WorkbookFactory.create(fls);
		String data = workbook.getSheet(sheetName).getRow(rowindex).getCell(cellindex).getStringCellValue();
		workbook.close();
		return data;
	}

	public double readNumaricData(String sheetName, int rowindex, int cellindex)
			throws IOException, EncryptedDocumentException {
		FileInputStream fls = new FileInputStream("./src/test/resourcesexcelsampledata.xlxs");
		Workbook workbook = WorkbookFactory.create(fls);
		double data = workbook.getSheet(sheetName).getRow(cellindex).getCell(cellindex).getNumericCellValue();
		workbook.close();
		return data;

	}
}
