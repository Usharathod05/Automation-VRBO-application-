package com.vrbo.qspiders.pomrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class VrboRecommendedPropertyPage {
	WebDriver driver;

	public VrboRecommendedPropertyPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//button[@class='btn btn-default sharing-widget__button--expanded btn-xs']")
	private WebElement shareButton;
	@FindBy(xpath = "//li[@class='Navigation__li']")
	private WebElement aboutButtonNavigationLink;
	@FindBy(xpath = "(//li[@class='Navigation__li'])[2]")
	private WebElement PoliciesNavigationLink;
	@FindBy(xpath = "(//li[@class='Navigation__li'])[3]")
	private WebElement FacilitiesNavigationLink;
	@FindBy(xpath = "(//li[@class='Navigation__li'])[4]")
	private WebElement ReviewsNavigationLink;
	@FindBy(xpath = "(//li[@class='Navigation__li'])[5]")
	private WebElement roomsAndBedsNavigationLink;
	@FindBy(xpath = "(//li[@class='Navigation__li'])[6]")
	private WebElement LocationNavigationLink;
	@FindBy(xpath = "(//li[@class='Navigation__li'])[7]")
	private WebElement availabilityNavigationLink;
	@FindBy(xpath = "(//li[@class='Navigation__li'])[8]")
	private WebElement HostNavigationLink;
	@FindBy(xpath = "//div[@class='primary-cta']")
	private WebElement BookNowButton;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getShareButton() {
		return shareButton;
	}

	public void setShareButton(WebElement shareButton) {
		this.shareButton = shareButton;
	}

	public WebElement getAboutButtonNavigationLink() {
		return aboutButtonNavigationLink;
	}

	public void setAboutButtonNavigationLink(WebElement aboutButtonNavigationLink) {
		this.aboutButtonNavigationLink = aboutButtonNavigationLink;
	}

	public WebElement getPoliciesNavigationLink() {
		return PoliciesNavigationLink;
	}

	public void setPoliciesNavigationLink(WebElement policiesNavigationLink) {
		PoliciesNavigationLink = policiesNavigationLink;
	}

	public WebElement getFacilitiesNavigationLink() {
		return FacilitiesNavigationLink;
	}

	public void setFacilitiesNavigationLink(WebElement facilitiesNavigationLink) {
		FacilitiesNavigationLink = facilitiesNavigationLink;
	}

	public WebElement getReviewsNavigationLink() {
		return ReviewsNavigationLink;
	}

	public void setReviewsNavigationLink(WebElement reviewsNavigationLink) {
		ReviewsNavigationLink = reviewsNavigationLink;
	}

	public WebElement getRoomsAndBedsNavigationLink() {
		return roomsAndBedsNavigationLink;
	}

	public void setRoomsAndBedsNavigationLink(WebElement roomsAndBedsNavigationLink) {
		this.roomsAndBedsNavigationLink = roomsAndBedsNavigationLink;
	}

	public WebElement getLocationNavigationLink() {
		return LocationNavigationLink;
	}

	public void setLocationNavigationLink(WebElement locationNavigationLink) {
		LocationNavigationLink = locationNavigationLink;
	}

	public WebElement getAvailabilityNavigationLink() {
		return availabilityNavigationLink;
	}

	public void setAvailabilityNavigationLink(WebElement availabilityNavigationLink) {
		this.availabilityNavigationLink = availabilityNavigationLink;
	}

	public WebElement getHostNavigationLink() {
		return HostNavigationLink;
	}

	public void setHostNavigationLink(WebElement hostNavigationLink) {
		HostNavigationLink = hostNavigationLink;
	}

	public WebElement getBookNowButton() {
		return BookNowButton;
	}

	public void setBookNowButton(WebElement bookNowButton) {
		BookNowButton = bookNowButton;
	}

}
